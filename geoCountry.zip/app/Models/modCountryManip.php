<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Schema\Blueprint;
use Illuminate\Database\Eloquent\Model;

class modCountryManip extends Model
{
    use HasFactory;
      
    public function __construct() {     
    }
    
    //check for tableExists
    private function tableExists($name){
        if(!Schema::hasTable($name)){
            return true;
        }
        else{
            return false;
        }
    }

    /* downloads the zip file from external url and returnes thw contents
     * of the csv file.
     */
    private static function downloadContents($url) {
        $data = file_get_contents($url);

        $path = tempnam(sys_get_temp_dir(), 'prefix');

        $temp = fopen($path, 'w');
        fwrite($temp, $data);
        fseek($temp, 0);
        fclose($temp);

        $pathExtracted = tempnam(sys_get_temp_dir(), 'prefix');

        $filenameInsideZip = 'GeoIPCountryWhois.csv';
        copy("zip://".$path."#".$filenameInsideZip, $pathExtracted);

        $row = 1;
        $csvEntries=[];
        
        if (($handle = fopen($pathExtracted, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
               array_push($csvEntries, $data);
            }
            fclose($handle);
        }
        unlink($path);
        unlink($pathExtracted);

        return $csvEntries;
    }

    /**
     * create dbases if not exist
     */
    private static function createDB($name){
        try {
            $query = "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = ?";
            $db = DB::select($query, [$name]);
            if(count($db)===0){
                DB::statement('CREATE DATABASE '.$name);
                
                self::configureConnectionByName($name);
              //  DB::connection($name);
                return true;                
            }
        }
        catch(Exception $e){
            if (empty($db)) {
                DB::statement('CREATE DATABASE '.$name);
                
                self::configureConnectionByName($name);
            }
            return false;
        }
    }

    //select db to use
    private static function configureConnectionByName($tenantName)
    {
        DB::disconnect('mysql'); 
        Config::set('database.connections.mysql.database', $tenantName);
        DB::reconnect();
    }

    //creates new table
    public static function create($name){
        if(self::createDB('geoLocation')){
            if (!Schema::hasTable($name)) {
                 Schema::create($name, function($table)
                 {
                     $table->increments('id');                              
                     $table->string('IP')->unique();
                     $table->string('DNS');
                     $table->integer('COL1');
                     $table->integer('COL2');
                     $table->string('countryCode');
                     $table->string('country');             
                 });

                 $url ='https://php-dev-task.s3-eu-west-1.amazonaws.com/GeoIPCountryCSV.zip';
                 $content = self::downloadContents($url);   

                 //call method to insert a new row for each entry in CSV
                 foreach($content as $row =>$data){
                     $result = self::insert(
                           $name,
                           $data[0],  
                           $data[1],  
                           $data[2],  
                           $data[3],  
                           $data[4],  
                           $data[5],  
                     );

                     if($result){}
                 }

             }       
        
        } 
    }

    //select recodes by given Column
    public function select($table, $column, $value){
        $results = DB::select('select * from '.$table.' where '.$column.' = '.value);

        return $results;
    }

    //insert new row into dbase
    public static function insert($table, $ip, $dns, $col1, $col2, $countryCode, $country){
        $results = DB::insert('insert into '.$table.' (IP, DNS, COL1, COL2, countryCode, country) values (?, ?, ?, ?, ?, ? )', [
            $ip, $dns, $col1, $col2, $countryCode, $country]);

        return $results;

    }

    //updates existing row
//    public function update($table, $ip, $dns, $col1, $col2, $countryCode, $country){
//    /*    $results = DB::update('update '.$table.' set ip' => $ip,
//            'dns' => $dns,
//            'col1' => $col1,
//            'col2' => $col2,            
//            'countryCode' => $countryCode,            
//            'country' => $country        
//        'where ip = '.$ip );
//
//        return $results;*/
//
//    }
    
  //  use HasFactory;
}
