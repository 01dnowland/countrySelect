<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\modCountryManip;

class clsCountryManip extends Controller
{
    public function create() {
        $createDB = modCountryManip::create('locations');
        return $createDB;
    }
    
    public function locationByIP($ip){
        $selectRecord = modCountryManip::select('locations', 'IP', $ip);
        return $selectRecord;        
    }
}